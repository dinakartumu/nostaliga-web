window.YTD.tweets.part0 = [
  {
    "tweet": {
      "id_str": "1524289669592100864",
      "full_text": "https://t.co/OAxHwdqRGy",
      "created_at": "Thu Sep 03 16:03:00 +0000 2026",
      "favorite_count": "0",
      "retweet_count": "0",
      "extended_entities": {
        "media": [
          {
            "expanded_url": "https://x.com/dinakartumu/status/1524289669592100864/photo/1",
            "indices": [
              "0",
              "23"
            ],
            "url": "https://t.co/OAxHwdqRGy",
            "media_url": "http://pbs.twimg.com/media/FSddXzRUUAESFqX.jpg",
            "id_str": "1524289662369419265",
            "id": "1524289662369419265",
            "media_url_https": "https://pbs.twimg.com/media/FSddXzRUUAESFqX.jpg",
            "sizes": {
              "large": {
                "w": "1536",
                "h": "2048",
                "resize": "fit"
              },
              "thumb": {
                "w": "150",
                "h": "150",
                "resize": "crop"
              },
              "medium": {
                "w": "900",
                "h": "1200",
                "resize": "fit"
              },
              "small": {
                "w": "510",
                "h": "680",
                "resize": "fit"
              }
            },
            "type": "photo",
            "display_url": "pic.x.com/OAxHwdqRGy"
          }
        ]
      }
    }
  },
  {
    "tweet": {
      "id_str": "1522838576261595136",
      "full_text": "Fifty six https://t.co/vhfWKyIieS",
      "created_at": "Fri Sep 04 16:03:00 +0000 2026",
      "favorite_count": "0",
      "retweet_count": "0",
      "extended_entities": {
        "media": [
          {
            "expanded_url": "https://x.com/dinakartumu/status/1522838576261595136/photo/1",
            "indices": [
              "10",
              "33"
            ],
            "url": "https://t.co/vhfWKyIieS",
            "media_url": "http://pbs.twimg.com/media/FSI1mnJVgAExqXw.jpg",
            "id_str": "1522838561464090625",
            "id": "1522838561464090625",
            "media_url_https": "https://pbs.twimg.com/media/FSI1mnJVgAExqXw.jpg",
            "sizes": {
              "medium": {
                "w": "900",
                "h": "1200",
                "resize": "fit"
              },
              "thumb": {
                "w": "150",
                "h": "150",
                "resize": "crop"
              },
              "small": {
                "w": "510",
                "h": "680",
                "resize": "fit"
              },
              "large": {
                "w": "1536",
                "h": "2048",
                "resize": "fit"
              }
            },
            "type": "photo",
            "display_url": "pic.x.com/vhfWKyIieS"
          }
        ]
      }
    }
  },
  {
    "tweet": {
      "id_str": "1522108898932518912",
      "full_text": "Fifty three https://t.co/KzRKckZqzG",
      "created_at": "Sat Sep 05 16:03:00 +0000 2026",
      "favorite_count": "0",
      "retweet_count": "0",
      "extended_entities": {
        "media": [
          {
            "expanded_url": "https://x.com/dinakartumu/status/1522108898932518912/photo/1",
            "indices": [
              "12",
              "35"
            ],
            "url": "https://t.co/KzRKckZqzG",
            "media_url": "http://pbs.twimg.com/media/FR-d9oDUcAA-2nu.jpg",
            "id_str": "1522108881123438592",
            "id": "1522108881123438592",
            "media_url_https": "https://pbs.twimg.com/media/FR-d9oDUcAA-2nu.jpg",
            "sizes": {
              "small": {
                "w": "510",
                "h": "680",
                "resize": "fit"
              },
              "large": {
                "w": "1536",
                "h": "2048",
                "resize": "fit"
              },
              "thumb": {
                "w": "150",
                "h": "150",
                "resize": "crop"
              },
              "medium": {
                "w": "900",
                "h": "1200",
                "resize": "fit"
              }
            },
            "type": "photo",
            "display_url": "pic.x.com/KzRKckZqzG"
          }
        ]
      }
    }
  },
  {
    "tweet": {
      "id_str": "1520982338192216064",
      "full_text": "Fifty two. https://t.co/tZI7frHKv4",
      "created_at": "Sun Sep 06 16:03:00 +0000 2026",
      "favorite_count": "0",
      "retweet_count": "0",
      "extended_entities": {
        "media": [
          {
            "expanded_url": "https://x.com/dinakartumu/status/1520982338192216064/photo/1",
            "indices": [
              "11",
              "34"
            ],
            "url": "https://t.co/tZI7frHKv4",
            "media_url": "http://pbs.twimg.com/media/FRudX51XIAAD6hC.jpg",
            "id_str": "1520982333154861056",
            "id": "1520982333154861056",
            "media_url_https": "https://pbs.twimg.com/media/FRudX51XIAAD6hC.jpg",
            "sizes": {
              "medium": {
                "w": "900",
                "h": "1200",
                "resize": "fit"
              },
              "small": {
                "w": "510",
                "h": "680",
                "resize": "fit"
              },
              "large": {
                "w": "1536",
                "h": "2048",
                "resize": "fit"
              },
              "thumb": {
                "w": "150",
                "h": "150",
                "resize": "crop"
              }
            },
            "type": "photo",
            "display_url": "pic.x.com/tZI7frHKv4"
          }
        ]
      }
    }
  },
  {
    "tweet": {
      "id_str": "1519658703359684610",
      "full_text": "Fifty. Yesterday\u2019s walk https://t.co/nIpNh3WJ8h",
      "created_at": "Tue Sep 08 01:03:00 +0000 2026",
      "favorite_count": "0",
      "retweet_count": "0",
      "extended_entities": {
        "media": [
          {
            "expanded_url": "https://x.com/dinakartumu/status/1519658703359684610/photo/1",
            "indices": [
              "24",
              "47"
            ],
            "url": "https://t.co/nIpNh3WJ8h",
            "media_url": "http://pbs.twimg.com/media/FRbphPeVcAAny-U.jpg",
            "id_str": "1519658681582841856",
            "id": "1519658681582841856",
            "media_url_https": "https://pbs.twimg.com/media/FRbphPeVcAAny-U.jpg",
            "sizes": {
              "medium": {
                "w": "900",
                "h": "1200",
                "resize": "fit"
              },
              "thumb": {
                "w": "150",
                "h": "150",
                "resize": "crop"
              },
              "large": {
                "w": "1536",
                "h": "2048",
                "resize": "fit"
              },
              "small": {
                "w": "510",
                "h": "680",
                "resize": "fit"
              }
            },
            "type": "photo",
            "display_url": "pic.x.com/nIpNh3WJ8h"
          }
        ]
      }
    }
  },
  {
    "tweet": {
      "id_str": "1519240073794838528",
      "full_text": "Forty nine https://t.co/liafVlEl9B",
      "created_at": "Tue Sep 08 16:03:00 +0000 2026",
      "favorite_count": "0",
      "retweet_count": "0",
      "extended_entities": {
        "media": [
          {
            "expanded_url": "https://x.com/dinakartumu/status/1519240073794838528/photo/1",
            "indices": [
              "11",
              "34"
            ],
            "url": "https://t.co/liafVlEl9B",
            "media_url": "http://pbs.twimg.com/media/FRVsyB7VcAAvtfw.jpg",
            "id_str": "1519240056073973760",
            "id": "1519240056073973760",
            "media_url_https": "https://pbs.twimg.com/media/FRVsyB7VcAAvtfw.jpg",
            "sizes": {
              "small": {
                "w": "510",
                "h": "680",
                "resize": "fit"
              },
              "thumb": {
                "w": "150",
                "h": "150",
                "resize": "crop"
              },
              "large": {
                "w": "1536",
                "h": "2048",
                "resize": "fit"
              },
              "medium": {
                "w": "900",
                "h": "1200",
                "resize": "fit"
              }
            },
            "type": "photo",
            "display_url": "pic.x.com/liafVlEl9B"
          }
        ]
      }
    }
  },
  {
    "tweet": {
      "id_str": "1518847755526934531",
      "full_text": "Forty eight https://t.co/1BVqjQXwvz",
      "created_at": "Thu Sep 10 01:03:00 +0000 2026",
      "favorite_count": "1",
      "retweet_count": "0",
      "extended_entities": {
        "media": [
          {
            "expanded_url": "https://x.com/dinakartumu/status/1518847755526934531/photo/1",
            "indices": [
              "12",
              "35"
            ],
            "url": "https://t.co/1BVqjQXwvz",
            "media_url": "http://pbs.twimg.com/media/FRQH9xDVIAA9Z-X.jpg",
            "id_str": "1518847732051419136",
            "id": "1518847732051419136",
            "media_url_https": "https://pbs.twimg.com/media/FRQH9xDVIAA9Z-X.jpg",
            "sizes": {
              "large": {
                "w": "1536",
                "h": "2048",
                "resize": "fit"
              },
              "thumb": {
                "w": "150",
                "h": "150",
                "resize": "crop"
              },
              "small": {
                "w": "510",
                "h": "680",
                "resize": "fit"
              },
              "medium": {
                "w": "900",
                "h": "1200",
                "resize": "fit"
              }
            },
            "type": "photo",
            "display_url": "pic.x.com/1BVqjQXwvz"
          }
        ]
      }
    }
  },
  {
    "tweet": {
      "id_str": "1517367728340082688",
      "full_text": "Forty six https://t.co/SZbcYYDIyj",
      "created_at": "Thu Sep 10 16:03:00 +0000 2026",
      "favorite_count": "0",
      "retweet_count": "0",
      "extended_entities": {
        "media": [
          {
            "expanded_url": "https://x.com/dinakartumu/status/1517367728340082688/photo/1",
            "indices": [
              "10",
              "33"
            ],
            "url": "https://t.co/SZbcYYDIyj",
            "media_url": "http://pbs.twimg.com/media/FQ7Fy1rVkAIgw0u.jpg",
            "id_str": "1517367601663414274",
            "id": "1517367601663414274",
            "media_url_https": "https://pbs.twimg.com/media/FQ7Fy1rVkAIgw0u.jpg",
            "sizes": {
              "small": {
                "w": "510",
                "h": "680",
                "resize": "fit"
              },
              "medium": {
                "w": "900",
                "h": "1200",
                "resize": "fit"
              },
              "thumb": {
                "w": "150",
                "h": "150",
                "resize": "crop"
              },
              "large": {
                "w": "1536",
                "h": "2048",
                "resize": "fit"
              }
            },
            "type": "photo",
            "display_url": "pic.x.com/SZbcYYDIyj"
          }
        ]
      }
    }
  }
]
